import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sinchu@123",
    database="student_db"
)

cursor = connection.cursor()

id = int(input("Enter Student ID: "))
name = input("Enter Student Name: ")
department = input("Enter Department: ")
marks1 = int(input("Enter Marks 1: "))
marks2 = int(input("Enter Marks 2: "))
marks3 = int(input("Enter Marks 3: "))

total = marks1 + marks2 + marks3
percentage = total / 3

if percentage >= 90:
    grade = "A+"
elif percentage >= 80:
    grade = "A"
elif percentage >= 70:
    grade = "B"
elif percentage >= 60:
    grade = "C"
elif percentage >= 50:
    grade = "D"
else:
    grade = "F"

sql = """
INSERT INTO students
(id, name, department, marks1, marks2, marks3, total, percentage, grade)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
"""

values = (id, name, department, marks1, marks2, marks3, total, percentage, grade)
cursor.execute(sql, values)
connection.commit()

print("Student added successfully!")

cursor.close()
connection.close()

import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sinchu@123",
    database="student_db"
)

cursor = connection.cursor()

import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sinchu@123",   # Replace with your MySQL password
    database="student_db"
)

cursor = connection.cursor()