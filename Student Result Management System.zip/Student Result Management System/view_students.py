import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sinchu@123",
    database="student_db"
)

cursor = connection.cursor()

cursor.execute("SELECT * FROM students")

rows = cursor.fetchall()

print("\n------ Student Records ------")

for row in rows:
    print("ID         :", row[0])
    print("Name       :", row[1])
    print("Department :", row[2])
    print("Marks 1    :", row[3])
    print("Marks 2    :", row[4])
    print("Marks 3    :", row[5])
    print("Total      :", row[6])
    print("Percentage :", row[7])
    print("Grade      :", row[8])
    print("-" * 30)

cursor.close()
connection.close()