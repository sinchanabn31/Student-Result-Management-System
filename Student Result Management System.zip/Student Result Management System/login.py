def login():

    USERNAME = "admin"
    PASSWORD = "admin123"

    print("\n========== ADMIN LOGIN ==========\n")

    username = input("Enter Username : ")
    password = input("Enter Password : ")

    if username == USERNAME and password == PASSWORD:
        print("\nLogin Successful!\n")
        return True
    else:
        print("\nInvalid Username or Password!")
        return False