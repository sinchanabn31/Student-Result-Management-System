from login import login

if login():

    while True:

        print("\n========================================")
        print(" STUDENT RESULT MANAGEMENT SYSTEM ")
        print("========================================")

        print("1. Add Student")
        print("2. View Students")
        print("3. Search Student")
        print("4. Update Student")
        print("5. Delete Student")
        print("6. Exit")

        choice = input("\nEnter Choice : ")

        if choice == "1":
            add_student()

        elif choice == "2":
            view_students()

        elif choice == "3":
            search_student()

        elif choice == "4":
            update_student()

        elif choice == "5":
            delete_student()

        elif choice == "6":
            print("\nThank You!")
            break

        else:
            print("Invalid Choice!")

cursor.close()
connection.close()

from database import connection, cursor


# ---------------- Add Student ---------------- #

def add_student():

    try:
        id = int(input("Enter Student ID : "))

        cursor.execute("SELECT * FROM students WHERE id=%s", (id,))
        if cursor.fetchone():
            print("Student ID already exists!")
            return

        name = input("Enter Name : ")
        department = input("Enter Department : ")

        marks1 = int(input("Enter Marks1 : "))
        marks2 = int(input("Enter Marks2 : "))
        marks3 = int(input("Enter Marks3 : "))

        total = marks1 + marks2 + marks3
        percentage = total / 3

        if percentage >= 90:
            grade = "A+"
        elif percentage >= 80:
            grade = "A"
        elif percentage >= 70:
            grade = "B"
        elif percentage >= 60:
            grade = "C"
        elif percentage >= 50:
            grade = "D"
        else:
            grade = "F"

        sql = """
        INSERT INTO students
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """

        values = (
            id,
            name,
            department,
            marks1,
            marks2,
            marks3,
            total,
            percentage,
            grade
        )

        cursor.execute(sql, values)
        connection.commit()

        print("\nStudent Added Successfully!")

    except Exception as e:
        print(e)


# ---------------- View Students ---------------- #

def view_students():

    cursor.execute("SELECT * FROM students")

    records = cursor.fetchall()

    if len(records) == 0:
        print("No Records Found")
        return

    print("\n---------------- STUDENTS ----------------")

    for row in records:

        print("ID         :", row[0])
        print("Name       :", row[1])
        print("Department :", row[2])
        print("Marks1     :", row[3])
        print("Marks2     :", row[4])
        print("Marks3     :", row[5])
        print("Total      :", row[6])
        print("Percentage :", row[7])
        print("Grade      :", row[8])

        print("------------------------------------------")


# ---------------- Search Student ---------------- #

def search_student():

    id = int(input("Enter Student ID : "))

    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))

    row = cursor.fetchone()

    if row:

        print("\nStudent Found\n")

        print("ID         :", row[0])
        print("Name       :", row[1])
        print("Department :", row[2])
        print("Marks1     :", row[3])
        print("Marks2     :", row[4])
        print("Marks3     :", row[5])
        print("Total      :", row[6])
        print("Percentage :", row[7])
        print("Grade      :", row[8])

    else:
        print("Student Not Found!")


# ---------------- Update Student ---------------- #

def update_student():

    id = int(input("Enter Student ID : "))

    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))

    if cursor.fetchone() is None:
        print("Student Not Found")
        return

    name = input("Enter New Name : ")
    department = input("Enter New Department : ")

    marks1 = int(input("Enter Marks1 : "))
    marks2 = int(input("Enter Marks2 : "))
    marks3 = int(input("Enter Marks3 : "))

    total = marks1 + marks2 + marks3
    percentage = total / 3

    if percentage >= 90:
        grade = "A+"
    elif percentage >= 80:
        grade = "A"
    elif percentage >= 70:
        grade = "B"
    elif percentage >= 60:
        grade = "C"
    elif percentage >= 50:
        grade = "D"
    else:
        grade = "F"

    sql = """
    UPDATE students
    SET name=%s,
    department=%s,
    marks1=%s,
    marks2=%s,
    marks3=%s,
    total=%s,
    percentage=%s,
    grade=%s
    WHERE id=%s
    """

    values = (
        name,
        department,
        marks1,
        marks2,
        marks3,
        total,
        percentage,
        grade,
        id
    )

    cursor.execute(sql, values)

    connection.commit()

    print("Student Updated Successfully!")


# ---------------- Delete Student ---------------- #

def delete_student():

    id = int(input("Enter Student ID : "))

    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))

    if cursor.fetchone() is None:
        print("Student Not Found")
        return

    cursor.execute("DELETE FROM students WHERE id=%s", (id,))

    connection.commit()

    print("Student Deleted Successfully!")


# ---------------- Main Menu ---------------- #

while True:

    print("\n========================================")
    print(" STUDENT RESULT MANAGEMENT SYSTEM ")
    print("========================================")

    print("1. Add Student")
    print("2. View Students")
    print("3. Search Student")
    print("4. Update Student")
    print("5. Delete Student")
    print("6. Exit")

    choice = input("\nEnter Choice : ")

    if choice == "1":
        add_student()

    elif choice == "2":
        view_students()

    elif choice == "3":
        search_student()

    elif choice == "4":
        update_student()

    elif choice == "5":
        delete_student()

    elif choice == "6":
        print("\nThank You!")
        break

    else:
        print("Invalid Choice!")

cursor.close()
connection.close()